# 学习目标：

<font color=#999AAA >提示：这里可以添加学习目标</font>  
```javascript
// 例如：一周掌握 Java 入门知识  
```
--- 

# 学习内容：

<font color=#999AAA >提示：这里可以添加要学的内容</font>  
例如：   
```markdown
1、 搭建 Java 开发环境  
2、 掌握 Java 基本语法  
3、 掌握条件语句  
4、 掌握循环语句  
```
--- 

# 学习时间：

<font color=#999AAA >提示：这里可以添加计划学习的时间</font>  
例如：  
```javascript
1、 周一至周五晚上 7 点—晚上9点  
2、 周六上午 9 点-上午 11 点  
3、 周日下午 3 点-下午 6 点  
```
--- 

# 学习产出：

<font color=#999AAA >提示：这里统计学习计划的总量</font>  
例如：  
```shell script
1、 技术笔记 2 遍  
2、CSDN 技术博客 3 篇  
3、 学习的 vlog 视频 1 个  
```

# 学习资料：
例如  
[![xtx.png](http://xyhnnx.gitee.io/vuepress-demo-dist/img/getdoc.png)](http://xyhnnx.gitee.io/vuepress-demo-dist/img/getdoc.png)
